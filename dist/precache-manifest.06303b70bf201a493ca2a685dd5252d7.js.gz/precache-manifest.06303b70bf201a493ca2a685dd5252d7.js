self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b7e2f95724b74bca2e9a",
    "url": "assets/css/main.b7e2f957.css"
  },
  {
    "revision": "b7e2f95724b74bca2e9a",
    "url": "assets/js/main.b7e2f957.js"
  },
  {
    "revision": "3e2867dadb4364d59558",
    "url": "assets/js/2.3e2867da.js"
  },
  {
    "revision": "842a348a0c63fdc5c3f2",
    "url": "assets/js/3.842a348a.js"
  },
  {
    "revision": "914beb2edbf74aaf9b1d",
    "url": "assets/js/4.914beb2e.js"
  },
  {
    "revision": "c5d6f27619a67afec184",
    "url": "assets/js/5.c5d6f276.js"
  },
  {
    "revision": "c97cedabc5416292cdd76d1907585b28",
    "url": "assets/img/icon-48x48.png"
  },
  {
    "revision": "ad69e107b1b806cbf5ea607984118163",
    "url": "favicon.ico"
  },
  {
    "revision": "3a84627f0f83500b9757dc13b2c6beab",
    "url": "manifest.json"
  },
  {
    "revision": "e044a63e034bf10304dad73138b8c74b",
    "url": "vendor/webcomponents/webcomponents-loader.js"
  },
  {
    "revision": "5958496c24d038cff6035b008df7ea66",
    "url": "vendor/helpers/babel-helpers-modern.min.js"
  },
  {
    "revision": "c80452ebf1ed83ca0ba794e4476839d3",
    "url": "vendor/helpers/babel-helpers.min.js"
  },
  {
    "revision": "5c703e8b191229cbad883fd90fac7732",
    "url": "vendor/helpers/regenerator-runtime.min.js"
  },
  {
    "revision": "976b78ec47dc83a5c6cf3738355e241e",
    "url": "assets/img/icon-192x192.png"
  },
  {
    "revision": "5a33b1c07d13f231fbf3c1268efe5fa3",
    "url": "assets/img/icon-144x144.png"
  },
  {
    "revision": "843dae45cc8698138303d886b173174d",
    "url": "assets/img/icon-512x512.png"
  },
  {
    "revision": "4c890689dccd81dfc8fa95b13a262034",
    "url": "assets/img/icon-72x72.png"
  },
  {
    "revision": "575d4c62b43be848d38a4b4a1aa11b5e",
    "url": "assets/img/icon-96x96.png"
  },
  {
    "revision": "9f271f5d6bcde9736d294a702125cbb0",
    "url": "index.html"
  }
]);