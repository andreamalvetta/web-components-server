self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a5ff0d20cf9f2901f5f8",
    "url": "assets/js/main.a5ff0d20.js"
  },
  {
    "revision": "5e7c522a62c85b7e8afa",
    "url": "assets/js/2.5e7c522a.js"
  },
  {
    "revision": "64c2a0db262539ac5cdf",
    "url": "assets/js/3.64c2a0db.js"
  },
  {
    "revision": "499a0d4790287cd071b2",
    "url": "assets/js/4.499a0d47.js"
  },
  {
    "revision": "bf0f789d6d6ae1eafc7e",
    "url": "assets/js/5.bf0f789d.js"
  },
  {
    "revision": "ad69e107b1b806cbf5ea607984118163",
    "url": "assets/js/../../favicon.ico"
  },
  {
    "revision": "3a84627f0f83500b9757dc13b2c6beab",
    "url": "assets/js/../../manifest.json"
  },
  {
    "revision": "e044a63e034bf10304dad73138b8c74b",
    "url": "assets/js/../../vendor/webcomponents/webcomponents-loader.js"
  },
  {
    "revision": "5958496c24d038cff6035b008df7ea66",
    "url": "assets/js/../../vendor/helpers/babel-helpers-modern.min.js"
  },
  {
    "revision": "c80452ebf1ed83ca0ba794e4476839d3",
    "url": "assets/js/../../vendor/helpers/babel-helpers.min.js"
  },
  {
    "revision": "5c703e8b191229cbad883fd90fac7732",
    "url": "assets/js/../../vendor/helpers/regenerator-runtime.min.js"
  },
  {
    "revision": "5a33b1c07d13f231fbf3c1268efe5fa3",
    "url": "assets/js/../img/icon-144x144.png"
  },
  {
    "revision": "976b78ec47dc83a5c6cf3738355e241e",
    "url": "assets/js/../img/icon-192x192.png"
  },
  {
    "revision": "c97cedabc5416292cdd76d1907585b28",
    "url": "assets/js/../img/icon-48x48.png"
  },
  {
    "revision": "843dae45cc8698138303d886b173174d",
    "url": "assets/js/../img/icon-512x512.png"
  },
  {
    "revision": "4c890689dccd81dfc8fa95b13a262034",
    "url": "assets/js/../img/icon-72x72.png"
  },
  {
    "revision": "575d4c62b43be848d38a4b4a1aa11b5e",
    "url": "assets/js/../img/icon-96x96.png"
  },
  {
    "revision": "04bfdd5b89f793fa817393edacb86b42",
    "url": "assets/js/../../index.html"
  }
]);