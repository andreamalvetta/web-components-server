self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3bc8190fc18fc2ead224",
    "url": "assets/css/main.3bc8190f.css"
  },
  {
    "revision": "3bc8190fc18fc2ead224",
    "url": "assets/js/main.3bc8190f.js"
  },
  {
    "revision": "449fad17eb6765e35ed7",
    "url": "assets/js/2.449fad17.js"
  },
  {
    "revision": "0f165ff73d2a6c4a3841",
    "url": "assets/js/3.0f165ff7.js"
  },
  {
    "revision": "914beb2edbf74aaf9b1d",
    "url": "assets/js/4.914beb2e.js"
  },
  {
    "revision": "c5d6f27619a67afec184",
    "url": "assets/js/5.c5d6f276.js"
  },
  {
    "revision": "c97cedabc5416292cdd76d1907585b28",
    "url": "assets/img/icon-48x48.png"
  },
  {
    "revision": "ad69e107b1b806cbf5ea607984118163",
    "url": "favicon.ico"
  },
  {
    "revision": "3a84627f0f83500b9757dc13b2c6beab",
    "url": "manifest.json"
  },
  {
    "revision": "e044a63e034bf10304dad73138b8c74b",
    "url": "vendor/webcomponents/webcomponents-loader.js"
  },
  {
    "revision": "5958496c24d038cff6035b008df7ea66",
    "url": "vendor/helpers/babel-helpers-modern.min.js"
  },
  {
    "revision": "c80452ebf1ed83ca0ba794e4476839d3",
    "url": "vendor/helpers/babel-helpers.min.js"
  },
  {
    "revision": "5c703e8b191229cbad883fd90fac7732",
    "url": "vendor/helpers/regenerator-runtime.min.js"
  },
  {
    "revision": "843dae45cc8698138303d886b173174d",
    "url": "assets/img/icon-512x512.png"
  },
  {
    "revision": "5a33b1c07d13f231fbf3c1268efe5fa3",
    "url": "assets/img/icon-144x144.png"
  },
  {
    "revision": "575d4c62b43be848d38a4b4a1aa11b5e",
    "url": "assets/img/icon-96x96.png"
  },
  {
    "revision": "976b78ec47dc83a5c6cf3738355e241e",
    "url": "assets/img/icon-192x192.png"
  },
  {
    "revision": "4c890689dccd81dfc8fa95b13a262034",
    "url": "assets/img/icon-72x72.png"
  },
  {
    "revision": "082840f84970fdb77d5913cc2ed0c44e",
    "url": "index.html"
  }
]);